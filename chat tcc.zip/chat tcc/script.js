document.addEventListener("DOMContentLoaded", function() {
  var messageInput = document.getElementById("message-input");
  var sendButton = document.getElementById("send-button");
  var chatMessages = document.getElementById("chat-messages");

  sendButton.addEventListener("click", function() {
    var message = messageInput.value;
    if (message.trim() !== "") {
      var messageElement = document.createElement("div");
      messageElement.classList.add("message");
      messageElement.classList.add("sent-message"); // Nova classe para mensagens enviadas
      messageElement.innerText = message;
      chatMessages.appendChild(messageElement);
      messageInput.value = "";
    }
  });

  messageInput.addEventListener("keydown", function(event) {
    if (event.keyCode === 13) {
      event.preventDefault(); // Impede a quebra de linha ao pressionar Enter
      sendButton.click();
    }
  });

  function updateChatHeader(contactId) {
    var chatHeader = document.getElementById("chat-header");
    var contact = document.querySelector(".contact:nth-child(" + contactId + ")");
    var contactInfo = contact.innerHTML;

    chatHeader.innerHTML = contactInfo;

    var selectedContact = document.querySelector(".contact.selected");
    if (selectedContact) {
      selectedContact.classList.remove("selected");
    }

    selectedContact = document.querySelector(".contact:nth-child(" + contactId + ")");
    selectedContact.classList.add("selected");

    var selectedContactName = selectedContact.querySelector(".contact-name").textContent;
    var selectedContactStatus = selectedContact.querySelector(".contact-status").textContent;
    var selectedContactAvatar = selectedContact.querySelector(".contact-avatar").src;

    var chatHeaderName = document.getElementById("chat-header-name");
    chatHeaderName.innerText = selectedContactName;
  }

  // Armazenar mensagem no localStorage(Fazer em banco de dados)
  function armazenarMensagem(mensagem) {
    var mensagensSalvas = JSON.parse(localStorage.getItem('mensagens')) || [];
    mensagensSalvas.push(mensagem);
    localStorage.setItem('mensagens', JSON.stringify(mensagensSalvas));
  }

  // Recupera mensagens do localStorage
  function recuperarMensagens() {
    var mensagensSalvas = JSON.parse(localStorage.getItem('mensagens')) || [];
    return mensagensSalvas;
  }

  // Obtém a referência para o campo de entrada de mensagem
  var messageInput = document.getElementById("message-input");

  // Adiciona um manipulador de evento "input" ao campo de entrada de mensagem
  messageInput.addEventListener("input", function() {
    if (this.value.length > 95) {
      this.value = this.value.slice(0, 95);
    }
  });

  // Obtém a referência para o botão de envio
  var sendButton = document.getElementById("send-button");

  // Adiciona um manipulador de evento "onclick" ao botão de envio
  sendButton.onclick = function() {
    // Obtém o valor do campo de entrada de mensagem
    var messageInputValue = messageInput.value;

    // Verifica se a mensagem ultrapassa o limite de caracteres
    if (messageInputValue.length > 95) {
      alert("A mensagem excede o limite de 95 caracteres!");
    } else {
      // Continua com o código de envio da mensagem
      // ...
    }
  };
});
document.addEventListener("DOMContentLoaded", function() {
  var messageInput = document.getElementById("message-input");
  var sendButton = document.getElementById("send-button");
  var chatMessages = document.getElementById("chat-messages");

  sendButton.addEventListener("click", function() {
    var message = messageInput.value;
    if (message.trim() !== "") {
      var messageElement = document.createElement("div");
      messageElement.classList.add("message");
      messageElement.classList.add("sent-message"); // Nova classe para mensagens enviadas
      messageElement.innerText = message;
      chatMessages.appendChild(messageElement);
      messageInput.value = "";
    }
  });

  messageInput.addEventListener("keydown", function(event) {
    if (event.keyCode === 13) {
      event.preventDefault(); // Impede a quebra de linha ao pressionar Enter
      sendButton.click();
    }
  });

  function updateChatHeader(contactId) {
    var chatHeader = document.getElementById("chat-header");
    var contact = document.querySelector(".contact:nth-child(" + contactId + ")");
    var contactInfo = contact.innerHTML;

    chatHeader.innerHTML = contactInfo;

    var selectedContact = document.querySelector(".contact.selected");
    if (selectedContact) {
      selectedContact.classList.remove("selected");
    }

    selectedContact = document.querySelector(".contact:nth-child(" + contactId + ")");
    selectedContact.classList.add("selected");

    var selectedContactName = selectedContact.querySelector(".contact-name").textContent;
    var selectedContactStatus = selectedContact.querySelector(".contact-status").textContent;
    var selectedContactAvatar = selectedContact.querySelector(".contact-avatar").src;

    var chatHeaderName = document.getElementById("chat-header-name");
    chatHeaderName.innerText = selectedContactName;
  }

  // Armazenar mensagem no localStorage(Fazer em banco de dados)
  function armazenarMensagem(mensagem) {
    var mensagensSalvas = JSON.parse(localStorage.getItem('mensagens')) || [];
    mensagensSalvas.push(mensagem);
    localStorage.setItem('mensagens', JSON.stringify(mensagensSalvas));
  }

  // Recupera mensagens do localStorage
  function recuperarMensagens() {
    var mensagensSalvas = JSON.parse(localStorage.getItem('mensagens')) || [];
    return mensagensSalvas;
  }

  // Obtém a referência para o campo de entrada de mensagem
  var messageInput = document.getElementById("message-input");

  // Adiciona um manipulador de evento "input" ao campo de entrada de mensagem
  messageInput.addEventListener("input", function() {
    if (this.value.length > 95) {
      this.value = this.value.slice(0, 95);
    }
  });

  // Obtém a referência para o botão de envio
  var sendButton = document.getElementById("send-button");

  // Adiciona um manipulador de evento "onclick" ao botão de envio
  sendButton.onclick = function() {
    // Obtém o valor do campo de entrada de mensagem
    var messageInputValue = messageInput.value;

    // Verifica se a mensagem ultrapassa o limite de caracteres
    if (messageInputValue.length > 95) {
      alert("A mensagem excede o limite de 95 caracteres!");
    } else {
      // Continua com o código de envio da mensagem
      // ...
    }
  };

  // Selecionar o primeiro contato como padrão ao carregar a página
  var defaultContact = document.querySelector(".contact:nth-child(1)");
  if (defaultContact) {
    defaultContact.classList.add("selected");

    var defaultContactName = defaultContact.querySelector(".contact-name").textContent;
    var chatHeaderName = document.getElementById("chat-header-name");
    chatHeaderName.innerText = defaultContactName;
  }
});
